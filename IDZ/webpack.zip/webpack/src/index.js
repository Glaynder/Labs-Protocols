import "./style.scss";
import "./responsive.scss";
console.log("webpack scss to css");